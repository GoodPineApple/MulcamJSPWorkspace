package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ArticleDAO;
import service.ArticleService;
import vo.ArticleVO;
import vo.PageVO;

@WebServlet(urlPatterns="/board.do")
public class Controller extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		execute(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("ecu-kr");
		execute(req, resp);
	}
	
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");
		String viewPath = "";
		ArticleDAO dao = ArticleDAO.getInstance();
		ArticleService service = ArticleService.getInstance();
		
		if(action == null || action.equals("main")) {
			String pageStr = req.getParameter("page");
			int page = 1;
			if(pageStr != null && pageStr.length()>0) {
				page = Integer.parseInt(pageStr);
			}
			System.out.println(page);
			PageVO articlePage = service.makePage(page);
			System.out.println("articlePage:"+articlePage);
			req.setAttribute("articlePage", articlePage);
			viewPath = "boardList.jsp";
		} else if(action.equals("write")){
			viewPath = "write_form.jsp";
		}
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPath);
		dispatcher.forward(req, resp);
	}
}
